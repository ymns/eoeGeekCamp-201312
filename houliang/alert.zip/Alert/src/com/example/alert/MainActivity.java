package com.example.alert;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {
	private static Button mbtn;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mbtn = (Button) findViewById(R.id.btn);
		MyListener listener=new MyListener();
		mbtn.setOnClickListener(listener);
		// mbtn.setOnClickListener(new OnClickListener() {
		//
		// @Override
		// public void onClick(View v) {
		// new AlertDialog.Builder(MainActivity.this).setTitle(
		// "Alert").setMessage("�Ի���")
		// .setPositiveButton("ȷ��",
		// new DialogInterface.OnClickListener() {
		// public void onClick(
		// DialogInterface dialoginterface,
		// int i) {
		// }
		// }).show();
		// }
		// });
	}
	private class MyListener implements OnClickListener {

		@Override
		public void onClick(View v) {
			Builder alert= new AlertDialog.Builder(MainActivity.this);
			alert.setTitle("��ӭ����");
			alert.setMessage("������");
			alert.setIcon(R.drawable.ic_launcher);
			alert.setPositiveButton("ȷ��",new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					finish();
				}
			});
			alert.create();
			alert.show();
		}
		
	}
	

	

}
